const btn = document.getElementById("btnLogin");
const msg = document.getElementById("msg");
const usernameEl = document.getElementById("username");
const passwordEl = document.getElementById("password");

btn.addEventListener("click", async () => {
  msg.textContent = "Đang kiểm tra thông tin...";
  msg.className = "lux-msg";

  try {
    const res = await fetch("/admin/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        username: usernameEl.value.trim(),
        password: passwordEl.value.trim(),
      }),
    });

    const data = await res.json();

    if (data.status === "success") {
      msg.textContent = "Đăng nhập thành công. Dùng userId để gọi API khác.";
      msg.className = "lux-msg ok";
      console.log("Admin userId:", data.userId);
    } else {
      msg.textContent = data.message || "Sai tài khoản hoặc mật khẩu.";
      msg.className = "lux-msg error";
    }
  } catch (e) {
    msg.textContent = "Lỗi kết nối tới server.";
    msg.className = "lux-msg error";
  }
});
