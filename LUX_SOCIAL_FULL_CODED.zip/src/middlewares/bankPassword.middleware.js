const bankModel = require("../modules/bank/bank.model");

module.exports = (req, res, next) => {
  const { bankPassword } = req.body;
  if (!bankPassword) return res.status(400).json({ status: "error", message: "Missing bankPassword" });

  const account = bankModel.getByUserId(req.user.id);
  if (!account || account.bankPassword !== bankPassword) {
    return res.status(401).json({ status: "error", message: "Invalid bank password" });
  }
  next();
};
