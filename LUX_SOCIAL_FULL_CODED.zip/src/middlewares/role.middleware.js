module.exports.requireRole = (roles) => {
  return (req, res, next) => {
    if (!req.user) return res.status(401).json({ status: "error", message: "Unauthorized" });
    if (!roles.includes(req.user.accountType) && !roles.includes(req.user.systemRole)) {
      return res.status(403).json({ status: "error", message: "Forbidden" });
    }
    next();
  };
};
