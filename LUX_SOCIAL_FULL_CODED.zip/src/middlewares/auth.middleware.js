const userModel = require("../modules/user/user.model");

module.exports = (req, res, next) => {
  const userId = req.header("x-user-id");
  if (!userId) return res.status(401).json({ status: "error", message: "Missing x-user-id header" });
  const user = userModel.getById(parseInt(userId));
  if (!user) return res.status(401).json({ status: "error", message: "Invalid user" });
  req.user = user;
  next();
};
