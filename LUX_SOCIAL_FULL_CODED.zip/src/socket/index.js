const chatSocket = require("../modules/chat/chat.socket");

module.exports = (io) => {
  io.on("connection", (socket) => {
    console.log("Socket connected:", socket.id);
    chatSocket(io, socket);
  });
};
