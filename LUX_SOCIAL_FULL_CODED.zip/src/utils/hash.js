module.exports.hashPassword = (p) => p;
module.exports.comparePassword = (p, h) => p === h;
