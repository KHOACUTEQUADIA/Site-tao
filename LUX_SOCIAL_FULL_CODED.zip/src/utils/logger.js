module.exports.log = (...args) => console.log("[LUX]", ...args);
