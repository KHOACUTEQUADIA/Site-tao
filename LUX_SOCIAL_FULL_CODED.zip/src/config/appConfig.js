module.exports = {
  tokenSecret: "LUX_SUPER_SIMPLE_SECRET"
};
