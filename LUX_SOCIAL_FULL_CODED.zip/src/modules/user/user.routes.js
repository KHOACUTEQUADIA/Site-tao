const router = require("express").Router();
const userModel = require("./user.model");
const auth = require("../../middlewares/auth.middleware");

router.get("/me", auth, (req, res) => {
  res.json({ user: req.user });
});

router.get("/search", auth, (req, res) => {
  const key = req.query.key || "";
  res.json({ results: userModel.search(key) });
});

router.post("/friend/request", auth, (req, res) => {
  const { toId } = req.body;
  try {
    userModel.sendFriendRequest(req.user.id, parseInt(toId));
    res.json({ status: "success", message: "Đã gửi lời mời kết bạn" });
  } catch (e) {
    res.status(400).json({ status: "error", message: e.message });
  }
});

router.post("/friend/accept", auth, (req, res) => {
  const { fromId } = req.body;
  try {
    userModel.acceptFriendRequest(req.user.id, parseInt(fromId));
    res.json({ status: "success", message: "Đã trở thành bạn bè" });
  } catch (e) {
    res.status(400).json({ status: "error", message: e.message });
  }
});

router.get("/friends", auth, (req, res) => {
  const ids = req.user.friends || [];
  const all = userModel.getAll();
  res.json({ friends: all.filter((u) => ids.includes(u.id)) });
});

router.get("/friend-requests", auth, (req, res) => {
  const ids = req.user.friendRequests || [];
  const all = userModel.getAll();
  res.json({ requests: all.filter((u) => ids.includes(u.id)) });
});

module.exports = router;
