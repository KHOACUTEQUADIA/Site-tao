const { randomId } = require("../../utils/random");

let USERS = [
  {
    id: 1,
    username: "adminlux",
    password: "sensei123",
    accountType: "admin",
    systemRole: "admin",
    money: 999999,
    friends: [],
    friendRequests: [],
    bio: "LUX System Owner",
    createdAt: new Date().toISOString()
  }
];

module.exports = {
  getAll: () => USERS,
  getById: (id) => USERS.find((u) => u.id === id),
  getByUsername: (username) => USERS.find((u) => u.username === username),
  create: ({ username, password }) => {
    const exists = USERS.find((u) => u.username === username);
    if (exists) throw new Error("Username already exists");
    const user = {
      id: randomId(),
      username,
      password,
      accountType: "free",
      systemRole: "user",
      money: 0,
      friends: [],
      friendRequests: [],
      bio: "",
      createdAt: new Date().toISOString()
    };
    USERS.push(user);
    return user;
  },
  update: (id, data) => {
    const u = USERS.find((x) => x.id === id);
    if (!u) return null;
    Object.assign(u, data);
    return u;
  },
  updateMoney: (id, amount) => {
    const u = USERS.find((x) => x.id === id);
    if (!u) return null;
    u.money += amount;
    return u;
  },
  search: (key) => {
    const k = key.toLowerCase();
    return USERS.filter((u) => u.username.toLowerCase().includes(k));
  },
  sendFriendRequest: (fromId, toId) => {
    const from = USERS.find((u) => u.id === fromId);
    const to = USERS.find((u) => u.id === toId);
    if (!from || !to) throw new Error("User not found");
    if (to.friendRequests.includes(fromId)) return;
    if (to.friends.includes(fromId)) return;
    to.friendRequests.push(fromId);
  },
  acceptFriendRequest: (userId, fromId) => {
    const user = USERS.find((u) => u.id === userId);
    const from = USERS.find((u) => u.id === fromId);
    if (!user || !from) throw new Error("User not found");
    user.friendRequests = user.friendRequests.filter((id) => id !== fromId);
    if (!user.friends.includes(fromId)) user.friends.push(fromId);
    if (!from.friends.includes(userId)) from.friends.push(userId);
  }
};
