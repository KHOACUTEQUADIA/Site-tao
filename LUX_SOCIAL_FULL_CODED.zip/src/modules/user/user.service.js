// simple in-memory service via model
