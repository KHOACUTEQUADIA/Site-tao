const userModel = require("../user/user.model");
const bankModel = require("../bank/bank.model");
const subLog = require("../subscription/subscription.model");
const bankModelRaw = require("../bank/bank.model");

const PLANS = {
  free: { price: 0, days: 0 },
  plus: { price: 10000, days: 30 },
  premium: { price: 30000, days: 30 },
  ultra: { price: 100000, days: 30 }
};

module.exports = {
  login: (req, res) => {
    const { username, password } = req.body;
    if (username === "adminlux" && password === "sensei123") {
      const admin = userModel.getByUsername("adminlux");
      return res.json({
        status: "success",
        userId: admin.id,
        message: "Welcome Sensei to LUX ADMIN. Dùng x-user-id kèm userId để gọi API.",
      });
    }
    res.status(401).json({ status: "error", message: "Sai thông tin đăng nhập" });
  },

  listUsers: (req, res) => {
    res.json({ users: userModel.getAll() });
  },

  upgradeUser: (req, res) => {
    const { userId, type } = req.body;
    const u = userModel.update(parseInt(userId), { accountType: type });
    if (!u) return res.status(400).json({ status: "error", message: "User not found" });
    res.json({ status: "success", user: u });
  },

  addMoney: (req, res) => {
    const { userId, amount } = req.body;
    const u = userModel.updateMoney(parseInt(userId), parseInt(amount));
    if (!u) return res.status(400).json({ status: "error", message: "User not found" });
    const acc = bankModel.createForUser(u.id);
    bankModel.changeBalance(acc.accountNumber, parseInt(amount));
    res.json({ status: "success", user: u, bank: acc });
  },

  dashboard: (req, res) => {
    const users = userModel.getAll();
    res.json({
      system: "LUX SOCIAL",
      totalUsers: users.length,
      premium: users.filter((u) => u.accountType === "premium").length,
      ultra: users.filter((u) => u.accountType === "ultra").length,
      time: new Date().toISOString()
    });
  },

  createDepositCode: (req, res) => {
    const { amount } = req.body;
    try {
      const dc = bankModelRaw.createDepositCode(parseInt(amount));
      res.json({ status: "success", code: dc.code, amount: dc.amount });
    } catch (e) {
      res.status(400).json({ status: "error", message: e.message });
    }
  },

  getPlans: (req, res) => {
    res.json({ plans: PLANS });
  }
};
