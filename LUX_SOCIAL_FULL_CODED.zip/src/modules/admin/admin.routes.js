const router = require("express").Router();
const adminCtrl = require("./admin.controller");
const auth = require("../../middlewares/auth.middleware");
const { requireRole } = require("../../middlewares/role.middleware");

// login riêng admin
router.post("/login", adminCtrl.login);

// tất cả route dưới cần admin
router.use(auth, requireRole(["admin"]));

router.get("/users", adminCtrl.listUsers);
router.post("/upgrade", adminCtrl.upgradeUser);
router.post("/money", adminCtrl.addMoney);
router.get("/dashboard", adminCtrl.dashboard);
router.post("/deposit-code", adminCtrl.createDepositCode);
router.get("/plans", adminCtrl.getPlans);

module.exports = router;
