// no extra admin persistence
