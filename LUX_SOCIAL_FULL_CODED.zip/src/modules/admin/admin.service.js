// simple controller above uses models directly
