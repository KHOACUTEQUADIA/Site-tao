const router = require("express").Router();
const auth = require("../../middlewares/auth.middleware");

router.get("/features", auth, (req, res) => {
  res.json({
    tier: "premium",
    features: [
      "Tất cả Plus",
      "Đăng video",
      "Khung avatar cao cấp",
      "Highlight tên trong bình luận"
    ]
  });
});

module.exports = router;
