const router = require("express").Router();
const auth = require("../../middlewares/auth.middleware");
const userModel = require("../user/user.model");
const bankModel = require("../bank/bank.model");
const { addDays } = require("../../utils/time");
const subLog = require("./subscription.model");

const PLANS = {
  free: { price: 0, days: 0 },
  plus: { price: 10000, days: 30 },
  premium: { price: 30000, days: 30 },
  ultra: { price: 100000, days: 30 }
};

router.get("/plans", (req, res) => {
  res.json({ plans: PLANS });
});

router.get("/status", auth, (req, res) => {
  res.json({ accountType: req.user.accountType, subExpireAt: req.user.subExpireAt || null });
});

router.post("/buy", auth, (req, res) => {
  const { plan } = req.body;
  const p = PLANS[plan];
  if (!p) return res.status(400).json({ status: "error", message: "Invalid plan" });

  if (plan === "free") {
    userModel.update(req.user.id, { accountType: "free", subExpireAt: null });
    return res.json({ status: "success" });
  }

  const acc = bankModel.createForUser(req.user.id);
  if (acc.balance < p.price) {
    return res.status(400).json({ status: "error", message: "Not enough balance" });
  }
  bankModel.changeBalance(acc.accountNumber, -p.price);

  const expire = addDays(p.days);
  userModel.update(req.user.id, { accountType: plan, subExpireAt: expire });
  subLog.addLog({
    userId: req.user.id,
    plan,
    price: p.price,
    expireAt: expire,
    createdAt: new Date().toISOString()
  });
  res.json({ status: "success", plan, expireAt: expire });
});

module.exports = router;
