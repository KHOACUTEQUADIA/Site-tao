let LOGS = [];

module.exports = {
  addLog: (log) => LOGS.push(log),
  getByUserId: (userId) => LOGS.filter((l) => l.userId === userId)
};
