const router = require("express").Router();
const auth = require("../../middlewares/auth.middleware");
const postModel = require("./post.model");

router.post("/post", auth, (req, res) => {
  const { text } = req.body;
  if (!text) return res.status(400).json({ status: "error", message: "Missing text" });
  const p = postModel.createPost(req.user.id, text);
  res.json({ status: "success", post: p });
});

router.get("/feed", auth, (req, res) => {
  res.json({ posts: postModel.getFeed() });
});

router.get("/user/:userId", auth, (req, res) => {
  const list = postModel.getByUserId(parseInt(req.params.userId));
  res.json({ posts: list });
});

router.post("/like", auth, (req, res) => {
  const { postId } = req.body;
  try {
    const p = postModel.like(req.user.id, parseInt(postId));
    res.json({ status: "success", post: p });
  } catch (e) {
    res.status(400).json({ status: "error", message: e.message });
  }
});

router.post("/comment", auth, (req, res) => {
  const { postId, text } = req.body;
  try {
    const c = postModel.comment(req.user.id, parseInt(postId), text);
    res.json({ status: "success", comment: c });
  } catch (e) {
    res.status(400).json({ status: "error", message: e.message });
  }
});

router.get("/comments/:postId", auth, (req, res) => {
  const list = postModel.getComments(parseInt(req.params.postId));
  res.json({ comments: list });
});

router.post("/share", auth, (req, res) => {
  const { postId } = req.body;
  try {
    const s = postModel.share(req.user.id, parseInt(postId));
    res.json({ status: "success", share: s });
  } catch (e) {
    res.status(400).json({ status: "error", message: e.message });
  }
});

module.exports = router;
