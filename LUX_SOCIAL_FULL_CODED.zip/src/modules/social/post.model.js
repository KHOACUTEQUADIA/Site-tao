const { randomId } = require("../../utils/random");

let POSTS = [];
let COMMENTS = [];
let REACTIONS = [];
let SHARES = [];

module.exports = {
  createPost: (userId, text) => {
    const p = {
      id: randomId(),
      userId,
      text,
      likes: 0,
      comments: 0,
      shares: 0,
      views: 0,
      createdAt: new Date().toISOString()
    };
    POSTS.unshift(p);
    return p;
  },
  getFeed: () => POSTS,
  getByUserId: (userId) => POSTS.filter((p) => p.userId === userId),
  addView: (postId) => {
    const p = POSTS.find((p) => p.id === postId);
    if (p) p.views++;
  },
  like: (userId, postId) => {
    const p = POSTS.find((p) => p.id === postId);
    if (!p) throw new Error("Post not found");
    const existing = REACTIONS.find((r) => r.userId === userId && r.postId === postId);
    if (existing) return p;
    REACTIONS.push({ id: randomId(), userId, postId, createdAt: new Date().toISOString() });
    p.likes++;
    return p;
  },
  comment: (userId, postId, text) => {
    const p = POSTS.find((p) => p.id === postId);
    if (!p) throw new Error("Post not found");
    const c = { id: randomId(), userId, postId, text, createdAt: new Date().toISOString() };
    COMMENTS.push(c);
    p.comments++;
    return c;
  },
  getComments: (postId) => COMMENTS.filter((c) => c.postId === postId),
  share: (userId, postId) => {
    const p = POSTS.find((p) => p.id === postId);
    if (!p) throw new Error("Post not found");
    const s = { id: randomId(), userId, postId, createdAt: new Date().toISOString() };
    SHARES.push(s);
    p.shares++;
    return s;
  },
  buffPost: (postId, opts) => {
    const p = POSTS.find((p) => p.id === postId);
    if (!p) throw new Error("Post not found");
    if (opts.likes) p.likes += opts.likes;
    if (opts.comments) p.comments += opts.comments;
    if (opts.shares) p.shares += opts.shares;
    if (opts.views) p.views += opts.views;
    return p;
  }
};
