const router = require("express").Router();
const userModel = require("../user/user.model");
const { hashPassword, comparePassword } = require("../../utils/hash");

router.post("/register", (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) return res.status(400).json({ status: "error", message: "Missing username or password" });
  try {
    const user = userModel.create({ username, password: hashPassword(password) });
    res.json({ status: "success", userId: user.id });
  } catch (e) {
    res.status(400).json({ status: "error", message: e.message });
  }
});

router.post("/login", (req, res) => {
  const { username, password } = req.body;
  const user = userModel.getByUsername(username);
  if (!user) return res.status(401).json({ status: "error", message: "Sai tài khoản hoặc mật khẩu" });
  if (!comparePassword(password, user.password)) {
    return res.status(401).json({ status: "error", message: "Sai tài khoản hoặc mật khẩu" });
  }
  res.json({
    status: "success",
    userId: user.id,
    accountType: user.accountType,
    systemRole: user.systemRole,
    message: "Đăng nhập thành công (dùng x-user-id để gọi API)"
  });
});

module.exports = router;
