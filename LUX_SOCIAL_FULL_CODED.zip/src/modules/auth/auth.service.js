// simple auth via in-memory user model
