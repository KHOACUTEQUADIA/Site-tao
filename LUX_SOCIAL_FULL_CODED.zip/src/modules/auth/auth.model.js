// shared via user.model
