const { randomId } = require("../../utils/random");

let ACCOUNTS = [];
let TRANSACTIONS = [];
let DEPOSIT_CODES = [];

module.exports = {
  createForUser: (userId) => {
    const exists = ACCOUNTS.find((a) => a.userId === userId);
    if (exists) return exists;
    const acc = {
      id: randomId(),
      userId,
      accountNumber: "88" + String(randomId()).padStart(8, "0"),
      bankPassword: "123456",
      balance: 0,
      createdAt: new Date().toISOString()
    };
    ACCOUNTS.push(acc);
    return acc;
  },
  getByUserId: (userId) => ACCOUNTS.find((a) => a.userId === userId),
  getByAccountNumber: (no) => ACCOUNTS.find((a) => a.accountNumber === no),
  addTransaction: (tx) => {
    TRANSACTIONS.push(tx);
  },
  getTransactionsForUser: (userId) => {
    const acc = ACCOUNTS.find((a) => a.userId === userId);
    if (!acc) return [];
    return TRANSACTIONS.filter((t) => t.fromAccount === acc.accountNumber || t.toAccount === acc.accountNumber);
  },
  changeBalance: (accountNumber, delta) => {
    const acc = ACCOUNTS.find((a) => a.accountNumber === accountNumber);
    if (!acc) throw new Error("Account not found");
    acc.balance += delta;
    return acc;
  },
  createDepositCode: (amount) => {
    const code = String(randomId());
    const dc = { code, amount, used: false };
    DEPOSIT_CODES.push(dc);
    return dc;
  },
  redeemDepositCode: (code) => {
    const dc = DEPOSIT_CODES.find((d) => d.code === code && !d.used);
    if (!dc) throw new Error("Invalid or used code");
    dc.used = true;
    return dc;
  }
};
