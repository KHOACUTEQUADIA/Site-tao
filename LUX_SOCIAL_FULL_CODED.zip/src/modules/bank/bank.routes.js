const router = require("express").Router();
const auth = require("../../middlewares/auth.middleware");
const bankModel = require("./bank.model");
const { randomId } = require("../../utils/random");

router.get("/me", auth, (req, res) => {
  const acc = bankModel.createForUser(req.user.id);
  res.json({ account: acc });
});

router.get("/history", auth, (req, res) => {
  const list = bankModel.getTransactionsForUser(req.user.id);
  res.json({ transactions: list });
});

router.post("/transfer", auth, (req, res) => {
  const { toAccount, amount } = req.body;
  const delta = parseInt(amount);
  if (!toAccount || isNaN(delta) || delta <= 0) {
    return res.status(400).json({ status: "error", message: "Invalid amount or account" });
  }
  const fromAcc = bankModel.createForUser(req.user.id);
  const toAcc = bankModel.getByAccountNumber(toAccount);
  if (!toAcc) return res.status(400).json({ status: "error", message: "Dest account not found" });
  if (fromAcc.balance < delta) return res.status(400).json({ status: "error", message: "Not enough balance" });

  bankModel.changeBalance(fromAcc.accountNumber, -delta);
  bankModel.changeBalance(toAcc.accountNumber, delta);
  bankModel.addTransaction({
    id: randomId(),
    type: "transfer",
    fromAccount: fromAcc.accountNumber,
    toAccount: toAcc.accountNumber,
    amount: delta,
    createdAt: new Date().toISOString()
  });
  res.json({ status: "success" });
});

router.post("/redeem-code", auth, (req, res) => {
  const { code } = req.body;
  try {
    const dc = bankModel.redeemDepositCode(code);
    const acc = bankModel.createForUser(req.user.id);
    bankModel.changeBalance(acc.accountNumber, dc.amount);
    bankModel.addTransaction({
      id: randomId(),
      type: "deposit-code",
      fromAccount: "SYSTEM",
      toAccount: acc.accountNumber,
      amount: dc.amount,
      createdAt: new Date().toISOString()
    });
    res.json({ status: "success", newBalance: acc.balance });
  } catch (e) {
    res.status(400).json({ status: "error", message: e.message });
  }
});

module.exports = router;
