const router = require("express").Router();
const auth = require("../../middlewares/auth.middleware");
const postModel = require("../social/post.model");

router.get("/features", auth, (req, res) => {
  res.json({
    tier: "ultra",
    features: [
      "Tất cả Premium",
      "Buff like / comment / share / view",
      "Đẩy bài lên TOP feed",
      "Badge LUX ULTRA"
    ]
  });
});

router.post("/buff", auth, (req, res) => {
  if (req.user.accountType !== "ultra" && req.user.systemRole !== "admin") {
    return res.status(403).json({ status: "error", message: "Chỉ dành cho ULTRA hoặc Admin" });
  }
  const { postId, likes = 0, comments = 0, shares = 0, views = 0 } = req.body;
  try {
    const p = postModel.buffPost(parseInt(postId), {
      likes: parseInt(likes) || 0,
      comments: parseInt(comments) || 0,
      shares: parseInt(shares) || 0,
      views: parseInt(views) || 0
    });
    res.json({ status: "success", post: p });
  } catch (e) {
    res.status(400).json({ status: "error", message: e.message });
  }
});

module.exports = router;
