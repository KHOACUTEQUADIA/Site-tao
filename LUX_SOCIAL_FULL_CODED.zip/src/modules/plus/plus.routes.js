const router = require("express").Router();
const auth = require("../../middlewares/auth.middleware");

router.get("/features", auth, (req, res) => {
  res.json({
    tier: "plus",
    features: [
      "Tăng giới hạn dung lượng upload",
      "Một số theme giao diện nâng cao",
      "Ưu tiên nhẹ trong feed"
    ]
  });
});

module.exports = router;
