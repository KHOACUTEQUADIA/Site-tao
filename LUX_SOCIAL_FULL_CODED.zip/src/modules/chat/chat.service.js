const chatModel = require("./chat.model");

module.exports = {
  addMessage: (fromId, toId, text) => chatModel.addMessage(fromId, toId, text),
  getMessages: (fromId, toId) => chatModel.getMessages(fromId, toId)
};
