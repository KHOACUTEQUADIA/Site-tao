const chatService = require("./chat.service");

module.exports = (io, socket) => {
  socket.on("chat:join", (userId) => {
    socket.data.userId = userId;
    console.log("User joined chat:", userId);
  });

  socket.on("chat:message", (payload) => {
    const msg = chatService.addMessage(payload.fromId, payload.toId, payload.text);
    io.emit("chat:message", msg);
  });
};
