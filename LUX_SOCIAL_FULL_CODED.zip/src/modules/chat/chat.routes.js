const router = require("express").Router();
const auth = require("../../middlewares/auth.middleware");
const chatService = require("./chat.service");

router.get("/history/:partnerId", auth, (req, res) => {
  const partnerId = parseInt(req.params.partnerId);
  const list = chatService.getMessages(req.user.id, partnerId);
  res.json({ messages: list });
});

router.post("/send", auth, (req, res) => {
  const { toId, text } = req.body;
  const msg = chatService.addMessage(req.user.id, parseInt(toId), text);
  res.json({ status: "success", message: msg });
});

module.exports = router;
