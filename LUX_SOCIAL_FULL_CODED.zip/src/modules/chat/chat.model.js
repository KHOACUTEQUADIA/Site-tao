const { randomId } = require("../../utils/random");

let CONVERSATIONS = [];
let MESSAGES = [];

module.exports = {
  getOrCreateConversation: (userA, userB) => {
    let c = CONVERSATIONS.find(
      (c) => (c.a === userA && c.b === userB) || (c.a === userB && c.b === userA)
    );
    if (!c) {
      c = { id: randomId(), a: userA, b: userB, createdAt: new Date().toISOString() };
      CONVERSATIONS.push(c);
    }
    return c;
  },
  addMessage: (fromId, toId, text) => {
    const conv = module.exports.getOrCreateConversation(fromId, toId);
    const m = {
      id: randomId(),
      conversationId: conv.id,
      fromId,
      toId,
      text,
      createdAt: new Date().toISOString()
    };
    MESSAGES.push(m);
    return m;
  },
  getMessages: (userA, userB) => {
    const conv = CONVERSATIONS.find(
      (c) => (c.a === userA && c.b === userB) || (c.a === userB && c.b === userA)
    );
    if (!conv) return [];
    return MESSAGES.filter((m) => m.conversationId === conv.id);
  }
};
