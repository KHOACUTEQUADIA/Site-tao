module.exports = (app) => {
  app.use("/auth", require("../modules/auth/auth.routes"));
  app.use("/user", require("../modules/user/user.routes"));
  app.use("/bank", require("../modules/bank/bank.routes"));
  app.use("/subscription", require("../modules/subscription/subscription.routes"));
  app.use("/social", require("../modules/social/social.routes"));
  app.use("/chat", require("../modules/chat/chat.routes"));
  app.use("/admin", require("../modules/admin/admin.routes"));
  app.use("/plus", require("../modules/plus/plus.routes"));
  app.use("/premium", require("../modules/premium/premium.routes"));
  app.use("/ultra", require("../modules/ultra/ultra.routes"));

  app.get("/health", (req, res) => {
    res.json({ status: "ok", app: "LUX Social Full" });
  });
};
