let USERS=[{
 id:1,username:'adminlux',password:'sensei123',accountType:'admin',
 money:999999,friends:[],friendRequests:[]
}];
module.exports={
 getAll:()=>USERS,
 getById:id=>USERS.find(u=>u.id==id),
 update:(id,data)=>{let u=USERS.find(x=>x.id==id);if(!u)return{status:'error'};Object.assign(u,data);return{status:'success',user:u};},
 updateMoney:(id,amt)=>{let u=USERS.find(x=>x.id==id);if(!u)return{status:'error'};u.money+=amt;return{status:'success',user:u};},
 search:key=>USERS.filter(u=>u.username.toLowerCase().includes(key.toLowerCase())),
 send:(from,to)=>{let t=USERS.find(u=>u.id==to);if(!t)return{error:true};t.friendRequests.push(from);return{ok:true};},
 accept:(uid,fid)=>{let u=USERS.find(x=>x.id==uid);let f=USERS.find(x=>x.id==fid);
 if(!u||!f)return{error:true};u.friends.push(fid);f.friends.push(uid);
 u.friendRequests=u.friendRequests.filter(a=>a!==fid);
 return{ok:true};}
};