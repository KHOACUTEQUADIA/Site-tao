const r=require('express').Router();
const u=require('./user.model');
r.get('/search',(req,res)=>res.json(u.search(req.query.key||'')));
r.post('/friend/send',(req,res)=>res.json(u.send(req.body.fromId,req.body.toId)));
r.post('/friend/accept',(req,res)=>res.json(u.accept(req.body.userId,req.body.fromId)));
module.exports=r;