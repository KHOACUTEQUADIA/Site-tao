const r=require('express').Router();
const c=require('./admin.controller');
r.post('/login',c.login);
r.get('/users',c.users);
r.post('/upgrade',c.upgrade);
r.post('/money',c.money);
r.get('/dashboard',c.dashboard);
module.exports=r;