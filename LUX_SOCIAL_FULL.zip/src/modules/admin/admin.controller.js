const users=require('../user/user.model');
module.exports={
 login:(req,res)=>{
  const{username,password}=req.body;
  if(username==='adminlux'&&password==='sensei123'){
   return res.json({status:'success',token:'LUX-TOKEN'});
  }
  res.json({status:'error',msg:'Sai tài khoản admin'});
 },
 users:(req,res)=>res.json(users.getAll()),
 upgrade:(req,res)=>res.json(users.update(req.body.userId,{accountType:req.body.type})),
 money:(req,res)=>res.json(users.updateMoney(req.body.userId,req.body.amount)),
 dashboard:(req,res)=>res.json({lux:true,total:users.getAll().length})
};