module.exports=app=>{
 app.use('/auth',require('../modules/auth/auth.routes'));
 app.use('/user',require('../modules/user/user.routes'));
 app.use('/admin',require('../modules/admin/admin.routes'));
};